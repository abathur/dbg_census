import soe

class Stats(soe.Stats):
	namespace = "eq2"

	def __str__(self):
		return "EVERQUST 2 STATS API"
