import soe

class Stats(soe.Stats):
	namespace = "ps2"

	def __str__(self):
		return "PLANETSIDE 2 STATS API"
